const mongoose = require("mongoose");

const todoSchema = new mongoose.Schema({

    firstName:{type:String,required:true}, 
    lastName :{type:String,required:false},
    email :{type:String,required:true},
    password:{type:String,required:true}

},
{
    versionKey:false,
    timestamps:true
})

const user = mongoose.model("user",todoSchema);

const todo = new mongoose.Schema({

    title:{type:String,required:true}, 

},
{
    versionKey:false,
    timestamps:true
})
const todomodel = mongoose.model("todo",todo)
module.exports = user;
