const express = require("express");
const user = require("../models/todo.model");

const router = express.Router();

router.post("",async(req,res) => {
          try {
              const todouser = await user.create(req.body);
              const show = await user.find().lean().exec();
              return res.status(201).send(show);
          } catch (error) {
              return res.status(501).send({error:error.message})
          }
})


module.exports = router