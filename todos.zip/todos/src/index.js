const express = require("express");
const todoconnect = require("./controllers/todo.controller");
const connect = require("./configs/db");
const app = express();

app.use("/register",todoconnect)
app.listen(5000,async () => {
    try {
        await connect(); 
        console.log("running on port 5000")
    } catch (error) {
        console.log({error:error.message})
    }
})